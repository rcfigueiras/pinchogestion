<?php
  //file: /view/messages/messages_en.php
  
  // empty array, no translation needed,
  // since keys are in english in the source code.  
  $i18n_messages = array()
?>
