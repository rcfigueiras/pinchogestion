<?php
// file: view/layouts/language_select_element.php
?>
<ul id="languagechooser">
	<li><a href="index.php?controller=language&amp;action=change&amp;lang=es">
	<?= i18n("Spanish") ?>
	</a></li>
	<li><a href="index.php?controller=language&amp;action=change&amp;lang=en">
	<?= i18n("English") ?>
	</a></li>
</ul>